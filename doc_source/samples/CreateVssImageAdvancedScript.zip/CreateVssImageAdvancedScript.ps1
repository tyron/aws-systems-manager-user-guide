# Copyright 2017 Amazon.com, Inc. or its affiliates. All Rights Reserved.

#
# Freezes All EBS volumes attached to an Ec2 instance except root volume
#
function Freeze-Instance {
    param(
        [string]$InstanceId,
        [string[]]$Devices,
        [string[]]$Volumes
    )
    $DevicesString = $Devices -join ','
    $VolumesString = $Volumes -join ','
    Write-Host "Starting Freeze for devices" $DevicesString $(Get-Date)
    #Call freeze SSM command and wait until complete
    $cmd = Send-SSMCommand -InstanceId $InstanceId -DocumentName AWSEC2-ManageVssIO -Parameter @{"Action" = "Freeze"; "Devices" = $DevicesString; "Volumes" = $VolumesString}
    $commandId = $cmd.CommandId
    Sleep -Seconds 2
    while ((Get-SSMCommandInvocation -CommandId $commandId).Status.Value -eq "InProgress" ) {
        Sleep -MilliSeconds 501
    }
    $CommandInvocation = Get-SSMCommandInvocation -CommandId $commandId -Details $true
    if ($CommandInvocation.CommandPlugins[0].Status.Value -eq "Failed") {
        throw  "Freeze command failed, command id: $($commandId), output: $($CommandInvocation.CommandPlugins[0].Output)"
    }
    Write-Host "Freeze complete, command id=$commandId $(Get-Date)" 
}

#
# Thaws EBS volumes attached to an Ec2 instance
#
function Thaw-Instance {
    param([string]$InstanceId)

    Write-Host "Starting Thaw $(Get-Date)" 
    #Call thaw SSM command and wait until complete
    $cmd = Send-SSMCommand -InstanceId $InstanceId -DocumentName AWSEC2-ManageVssIO -Parameter @{"Action" = "Thaw"}
    $commandId = $cmd.CommandId
    Sleep -Seconds 1
    while ((Get-SSMCommandInvocation -CommandId $commandId).Status.Value -eq "InProgress" ) {
        Sleep -Seconds 1
    }
    Write-Host "Thaw complete, command id=$commandId $(Get-Date)" 
    $CommandInvocation = Get-SSMCommandInvocation -CommandId $commandId -Details $true
    if ($CommandInvocation.CommandPlugins[0].Status.Value -eq "Failed") {

        throw "Thaw command failed $($commandId), output $CommandInvocation.CommandPlugins[0].Status"
    }
    
    $output = $CommandInvocation.CommandPlugins[0].Output
    $Status = $CommandInvocation.CommandPlugins[0].Status
    write-host $output
}

#
# Tag Snapshots
#
function Tag-Snapshots {
    param(
        [System.Object[]]$SnapshotsData,
        [boolean]$AppConsistent,
        [Parameter(Mandatory = $false)][amazon.EC2.Model.Tag[]]$Tags
    )
    if ($Tags -eq $null) {
        $Tags = @()
    }
    $Tag = new-object amazon.EC2.Model.Tag
    $Tag.Key = "AppConsistent"
    $Tag.Value = "$AppConsistent"
    $Tags += $Tag
    foreach ($SnapshotData in $SnapshotsData) {
        if ($null -ne $SnapshotData.SnapshotId) {
            $Tag = new-object amazon.EC2.Model.Tag
            $Tag.Key = "Device"
            $Tag.Value = $SnapshotData.Device
            $AllTags = $Tags + $Tag
            New-EC2Tag -Resources $SnapshotData.SnapshotId -Tags $AllTags
        }
    }
}

#
# Tag Image
#
function Tag-Image {
    param(
        [string]$ImageId,
        [boolean]$AppConsistent,
        [Parameter(Mandatory = $false)][amazon.EC2.Model.Tag[]]$Tags
    )
    if ($Tags -eq $null) {
        $Tags = @()
    }
    $Tag = new-object amazon.EC2.Model.Tag
    $Tag.Key = "AppConsistent"
    $Tag.Value = "$AppConsistent"
    $Tags += $Tag
    New-EC2Tag -Resources $ImageId -Tags $Tags
}

#
# Create consistent AMI of volumes attached to an EC2 instance
#
function Vss-Image {
    param(
        [string]$InstanceId,
        [Parameter(Mandatory = $false)][string]$ImageName,
        [Parameter(Mandatory = $false)][string]$Description,
        [Parameter(Mandatory = $false)][amazon.EC2.Model.Tag[]]$Tags
    )

    #Get attached voluems/devices
    $BlockDeviceMappings = (Get-EC2Instance -Instance $InstanceId).Instances.BlockDeviceMappings
    $SnapshotData = @()
    foreach ($BlockDeviceMapping in $BlockDeviceMappings) {
        #Exclude the boot volume, boot volumes are not supported using this script
        if ($BlockDeviceMapping.DeviceName -ne "/dev/sda1") {
            $SnapshotData +=
            New-Object PSObject -Property @{
                EbsVolumeId = $BlockDeviceMapping.Ebs.VolumeId
                Device      = $BlockDeviceMapping.DeviceName
                SnapshotId  = $null
            }         
        }
    }
    if ($SnapshotData.Count -eq 0) {
        Write-Error "Instance has no volumes to snapshot"
        exit 1
    }


    #Freeze IO on instance
    Freeze-Instance $InstanceId $SnapshotData.Device $SnapshotData.EbsVolumeId

    # Create Image
    if ($ImageName -eq $null) {
        $ImageName = "$InstanceId-$(Get-Date -UFormat '%Y-%m-%d-%H-%M-%S')"
    }
    $ImageId = (New-EC2Image -Name $ImageName -Description $Description -InstanceId $InstanceId -NoReboot:$true)
    Write-Host "Creating AMI" $ImageId $(Get-Date)

    [Amazon.EC2.Model.Image]$Image = (Get-EC2Image -ImageId $ImageId)

    foreach ($Data in $SnapshotData) {
        $DeviceData = $Image.BlockDeviceMappings | Where-Object { $_.DeviceName -eq $Data.Device }
        if ($null -ne $DeviceData) {
            $Data.SnapshotId = $DeviceData.Ebs.SnapshotId
        }
    }

    #Thaw IO on instance
    Try {
        Thaw-Instance $InstanceId
        Tag-Image $ImageId $true $Tags
        Tag-Snapshots $SnapshotData $true $Tags
    } Catch {
        #If Thaw fails (snapshots took to long), tag snapshots as AppConsistent=false
        Tag-Image $ImageId $false $Tags
        Tag-Snapshots $SnapshotData $false $Tags
    }
}

#Example usage
$Tags = @()
$Tag = new-object amazon.EC2.Model.Tag
$Tag.Key = "TagKey"
$Tag.Value = "TagValue"
$Tags += $Tag
Vss-Image -InstanceId $InstanceId -ImageName "myami" -Description "Created by adv script" -Tags $Tags
